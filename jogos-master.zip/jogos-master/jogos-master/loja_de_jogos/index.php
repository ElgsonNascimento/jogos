<html>

<head>
    <meta charset="utf-8">
    <title>nome da loja de jogos</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- <link rel="stylesheet" href="css/reset.css"> -->
</head>

<body>
    <header>
        <a href="index.html"><img src="imgs/logo.jpg" alt="Logo">
            <h1>Vapor</h1>
        </a>

        <nav>
            <a href="acessar_conta.html">acessar conta</a>
            <a href="criar_conta.html">criar conta</a>
        </nav>
    </header>
    <main>
        <div class="info-box">
            <h1 id="principal">Página principal</h1>
            <br>
            <div class="pesquisar">
                <a href="buscar.php">
                    Filtros
                </a>
            </div>
            <br>
        </div>

        <div class="oferta">
            <h2>Principais ofertas</h2>
            <img src="imgs/jogo1.png" alt="imagem do jogo 1">
            <h4>Little Nightmares 3</h4>
            <p>Little Nightmares III é um jogo de aventura imersivo que acompanha a jornada de Low e Alone,
                dois melhores amigos em busca de uma saída de Lugar Nenhum.</p>
            <button>Saiba mais</button>
        </div>
        <h2>Descubra também</h2>
        <div class="jogo">
            <img src="imgs/jogo2.png" alt="imagem do jogo 2">
            <h4>Red Dead Redemption 2</h4>
            <p>Avaliação: ⭐⭐⭐⭐⭐</p>
            <p>Genero: Ação, Aventura.</p>
        </div>

        <div class="jogo">
            <img src="imgs/jogo3.png" alt="imagem do jogo 3">
            <h4>Risk of Rain 2 </h4>
            <p>Avaliação: ⭐⭐⭐⭐⭐</p>
            <p>Genero: Roguelike, Co-op.</p>
        </div>

    </main>
    <button id="chat-toggle">💬</button>

    <div id="chatbox">
        <header>Ollama Chat</header>
        <div id="messages"></div>
        <div id="input-area">
            <input id="input" type="text" placeholder="Digite sua mensagem..." />
            <button id="send">➤</button>
        </div>
    </div>

    <script src="chat.js"></script>

    <script>
        const toggleBtn = document.getElementById('chat-toggle');
        const chatbox = document.getElementById('chatbox');

        toggleBtn.addEventListener('click', () => {
            chatbox.style.display = chatbox.style.display === 'flex' ? 'none' : 'flex';
        });
    </script>



    <footer>
        Caso tenha qualquer problema, se dirigir a nossa equipe de suporte:
        +55 41 99999-9999.
        por favor nos avalie
    </footer>

    <script>

        // buscando na sessão as variáveis username e loggedIn(bool)
        const username = sessionStorage.getItem("username");
        const loggedIn = sessionStorage.getItem("loggedIn");

        // Caso o usuario esteja logado, o header é modificado
        // com suas credenciais de sessão (header inteligente).
        if (loggedIn === "true") {
            const nav = document.querySelector("nav");
            nav.innerHTML = ""; // limpar links antigos com segurança

            // criar link "Perfil de... {usuario}"
            const perfil = document.createElement("a");
            perfil.href = "#";
            perfil.textContent = `Perfil de ${username}`; // textContent ao invés 
            // innerHTML pra prevenir xss.

            // criar link "Sair"
            const sair = document.createElement("a");
            sair.href = "#";
            sair.id = "logoutBtn";
            sair.textContent = "Sair";

            // adicionar os dois links na "nav" anterior
            nav.appendChild(perfil);
            nav.appendChild(sair);

            // atualizar mensagem de Boas vindas
            const boas_vindas = document.getElementById("principal");
            boas_vindas.textContent = `Bem-vindo(a), ${username}`;

            // botão de deslogar
            sair.addEventListener("click", (e) => {
                e.preventDefault();
                sessionStorage.removeItem("username"); // Remove os dados
                sessionStorage.removeItem("loggedIn"); // da sessão.
                window.location.reload(); // Recarrega a página.
            });
        }
    </script>


</body>

</html>